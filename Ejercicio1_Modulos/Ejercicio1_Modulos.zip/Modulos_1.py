import calculadora as calc

print(calc.sumar(5, 30))
print(calc.restar(5, 30))
print(calc.dividir(5, 30))
print(calc.multiplicar(5, 30))