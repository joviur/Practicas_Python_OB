f = open('archivo.txt','wt')
f.write('Escribo en el archivo\n')
f.write("Escribo de nuevo")
f.close()